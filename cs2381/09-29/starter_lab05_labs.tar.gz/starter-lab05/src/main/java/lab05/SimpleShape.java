package lab05;

import java.awt.Shape;
import java.awt.Color;
import java.awt.geom.*;

public interface SimpleShape {
    Color color();
    Shape toShape();
    SimpleShape flipY(int hh);
}

record Circle(double x, double y, double radius, Color color) implements SimpleShape {
    @Override
    public Shape toShape() {
        return new Ellipse2D.Double(x-radius, y-radius, 2*radius, 2*radius);
    }

    @Override
    public SimpleShape flipY(int hh) {
        return new Circle(x, hh - y, radius, color);
    }
}
