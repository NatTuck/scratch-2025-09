package lab05;

import java.awt.Color;

/**
 * Represents a bouncing ball for lab05.
 *
 * @param color
 * @param px     X position
 * @param py     Y position
 * @param vx     X velocity
 * @param vy     Y velocity
 */
public record Ball(Color color, int px, int py, int vx, int vy) {
    /**
     * Generate a random ball starting at x, y.
     *
     * @param  x  Initial x position.
     * @param  y  Initial y position.
     * @return    Newly created Ball.
     */
    static Ball random(int x, int y) {
        int vx = (int)(Math.random() * 20) - 14;
        int vy = (int)(Math.random() * 20) - 6;
        int rr = (int)(256 * Math.random());
        int gg = (int)(256 * Math.random());
        int bb = (int)(256 * Math.random());
        return new Ball(new Color(rr, gg, bb), x, y, vx, vy);
    }

    /**
     * Move the ball by its velocity.
     * Doesn't handle bouncing.
     *
     * @return Moved ball.
     */
    Ball move() {
        return new Ball(this.color,
                        this.px + this.vx,
                        this.py + this.vy,
                        this.vx,
                        this.vy + App.GRAVITY);
    }

    /**
     * If the value is outside the range, move it back into
     * range as if it had bounced off the end.
     *
     * @return An in-range value
     */
    static int bounceClamp(int xx, int xMin, int xMax) {
        if (xx < xMin) {
            xx += 2 * (xMin - xx);
        }
        if (xx > xMax) {
            xx -= 2 * (xx - xMax);
        }
        return xx;
    }

    Ball bounce() {
        return this;
    }

    /**
     * Generates the next version of the ball.
     *
     * @return A ball 
     */
    Ball tick() {
        return this.move().bounce();
    }

    Circle toCircle() {
        return new Circle(px(), py(), 50, color());
    }
}
