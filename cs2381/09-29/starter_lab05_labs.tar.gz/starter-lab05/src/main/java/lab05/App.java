package lab05;

public class App implements GfxApp {
    final static int GRAVITY = -1;

    ConsList<Ball> balls;

    public static void main(String[] args) {
        GfxWindow.launch(new App(), 800, 600);
    }

    App() {
        this.balls = ConsList.empty();
    }

    ConsList<Circle> getCircles() {
        ConsList<Circle> ys = ConsList.empty();
        for (var ball : balls) {
            var cc = ball.toCircle();
            ys = ConsList.cons(cc, ys);
        }
        return ys;
    }

    @Override
    public void onTick(GfxWindow gw, long frame) {
        ConsList<Ball> balls1 = ConsList.empty();
        for (var ball : balls) {
            balls1 = ConsList.cons(ball.tick(), balls1);
        }
        this.balls = balls1;
        gw.putShapes(this.getCircles());
    }

    @Override
    public void onMouse(GfxWindow gw, int x, int y, int btn) {
        //System.out.printf("App.onMouse(%d %d %d)\n", x, gw.getHeight() - y, btn);
        this.balls = ConsList.cons(Ball.random(x, gw.getHeight() - y), this.balls);
        gw.putShapes(this.getCircles());
    }

    @Override
    public void onKey(GfxWindow gw, String key) {
        //System.out.printf("App.onKey(%s)\n", key);
        this.balls = ConsList.empty();
        gw.putShapes(this.getCircles());
    }


}
