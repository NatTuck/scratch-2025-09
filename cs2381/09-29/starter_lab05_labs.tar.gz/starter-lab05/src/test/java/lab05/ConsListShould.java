package lab05;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConsListShould {

    @Test
    void have_working_iterator() {
        var xs = ConsList.of(1, 2, 3, 4);
        int sum = 0;

        for (var xx : xs) {
            sum += xx;
        }

        assertEquals(10, sum);
    }
}
