package lab05;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BallShould {
    @Test
    void bounce_off_ground() {
        var blue = GfxWindow.stringToColor("blue");

        var b1 = new Ball(blue, 100, 5, 3, -7);
        assertEquals(new Ball(blue, 103, 2, 3, 8), b1.tick());

        var b2 = new Ball(blue, 100, 20, 3, -7);
        assertEquals(new Ball(blue, 103, 13, 3, -8), b2.tick());
    }
}
