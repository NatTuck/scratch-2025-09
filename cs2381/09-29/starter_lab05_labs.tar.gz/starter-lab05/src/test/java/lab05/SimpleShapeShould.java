package lab05;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.geom.Rectangle2D;

public class SimpleShapeShould {
    @Test
    void include_squares() {
        // Remove this line.
        assertTrue(false);

        // Uncomment these:
        /*
        var blue = GfxWindow.stringToColor("blue");
        var sq = new Square(100, 100, 100, blue);
        var gs = sq.toShape();
        assertTrue(sq.toSquare instanceof Rectangle2D.Double);
        */
    }
}
