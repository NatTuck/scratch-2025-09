package lab05;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Dimension;

public class AppShould {

    @Test
    void move_balls_on_tick() {
        var blue = GfxWindow.stringToColor("blue");

        var app = new App();
        var gw = new GfxWindow(app, 800, 600);
        Dimension dim = new Dimension(400, 300);
        gw.setSize(dim);

        var b1 = new Ball(blue, 100, 100, 10, 10);
        app.balls = ConsList.of(b1);
        app.onTick(gw, 5);

        var b2 = app.balls.first();
        assertEquals(new Ball(blue, 110, 110, 10, 9), b2);
    }

    @Test
    void delete_oob_balls() {
        var blue = GfxWindow.stringToColor("blue");
        var red = GfxWindow.stringToColor("red");

        var app = new App();
        var gw = new GfxWindow(app, 800, 600);
        Dimension dim = new Dimension(400, 300);
        gw.setSize(dim);

        app.balls = ConsList.of(
            new Ball(blue, 100, 100, 10, 10),
            new Ball(red, -25, 100, 10, 10),
            new Ball(blue, 25, -25, 10, 10),
            new Ball(blue, 25, 900, 10, 10),
            new Ball(red, 900, 25, 10, 10),
            new Ball(blue, 300, 200, -10, -10)
        );

        app.onTick(gw, 5);

        assertEquals(4, app.balls.size());

        for (var ball : app.balls) {
            assertEquals(blue, ball.color());
        }
    }
}
